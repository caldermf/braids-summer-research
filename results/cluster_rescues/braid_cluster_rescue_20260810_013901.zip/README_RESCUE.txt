This archive excludes large .sqlite, .parquet, model, and binary files. It preserves configs, summaries, candidates, manifests, success markers, small logs, and a full file-size inventory.
